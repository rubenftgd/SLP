function headPhonesPrint()
    disp('Put your headphones!');
    disp('Sound starting in:');
    for s=3:-1:1
        disp(s);
        pause(1);
    end
end

